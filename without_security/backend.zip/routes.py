from database.models import User
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from starlette.responses import JSONResponse, HTMLResponse
from pydantic import BaseModel
from database.mysql_db import get_db

router = APIRouter()

# רשימה פשוטה לאחסון נתוני לקוחות
clients = []

class Client(BaseModel):
    name: str
    email: str

@router.post("/add_client")
def add_client(client: Client) -> JSONResponse:
    """
    API endpoint להוספת לקוח חדש.
    """
    clients.append({"name": client.name, "email": client.email})  # שמירת הנתונים ללא ולידציה
    return JSONResponse(content={"message": "Client added!"}, status_code=201)

@router.get("/list_clients")
def list_clients() -> HTMLResponse:
    """
    API endpoint להצגת לקוחות.
    """
    # יצירת HTML עם רשימת הלקוחות
    html_content = "".join([f"<p>{client['name']} - {client['email']}</p>" for client in clients])
    html_page = f"""
    <html>
        <body>
            <h1>Client List</h1>
            {html_content}
        </body>
    </html>
    """
    return HTMLResponse(content=html_page)

class RegisterRequest(BaseModel):
    username: str
    password: str
    email: str

@router.post("/register")
def register_user(request: RegisterRequest, db: Session = Depends(get_db)):
    # בדוק אם המשתמש כבר קיים
    existing_user = db.query(User).filter(User.username == request.username).first()
    if existing_user:
        return {"message": "Username already exists"}

    # יצירת משתמש חדש ושמירתו בבסיס הנתונים
    new_user = User(username=request.username, email=request.email, password=request.password)
    db.add(new_user)
    db.commit()

    return {"message": "User registered successfully!"}


class LoginRequest(BaseModel):
    username: str
    password: str




from sqlalchemy.sql import text
from fastapi import HTTPException

@router.post("/login")
def login_user(request: LoginRequest, db: Session = Depends(get_db)):
    query = text(f"SELECT * FROM user WHERE username = '{request.username}' AND password = '{request.password}'")
    print("Generated query:", query)  # Debugging query

    try:
        user = db.execute(query).fetchone()
        user_dict = dict(user._mapping) if user else None  # Safe conversion
    except Exception as e:
        print(f"SQL Execution Error: {e}")
        raise HTTPException(status_code=500, detail="Database error")

    if user_dict:
        return {"message": "Login successful!", "user": user_dict}

    raise HTTPException(status_code=401, detail="Invalid username or password")
##


##