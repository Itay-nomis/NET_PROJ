import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import '../styles/login.css';

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate(); // הוספת הניווט

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:5000/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      if (response.ok) {
        const data = await response.json();
        alert(data.message); // הודעת הצלחה
        navigate("/system"); // מעבר למסך ה-System
      } else {
        const errorData = await response.json();
        alert(errorData.detail); // הודעת שגיאה
      }
    } catch (error) {
      console.error("Error during login:", error);
      alert("An error occurred. Please try again.");
    }
  };

  return (
      <div className="login-container">
        <h2>Login to Comunication_LTD</h2>
        <form onSubmit={handleSubmit}>
          <label>
            Username:
            <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
            />
          </label>
          <br />
          <label>
            Password:
            <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
            />
          </label>
          <br />
          <button type="submit">Login</button>
        </form>
      </div>
  );
}

export default Login;
