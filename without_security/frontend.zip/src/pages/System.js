import React, { useState } from "react";

function System() {
    const [clientName, setClientName] = useState("");
    const [clientEmail, setClientEmail] = useState("");

    const addClient = async () => {
        await fetch("http://localhost:5000/add_client", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name: clientName, email: clientEmail }),
        });
        setClientName("");
        setClientEmail("");
        alert("Client added!");
    };

    const showClients = async () => {
        const response = await fetch("http://localhost:5000/list_clients");
        const data = await response.text();

        // עדכון ישיר של HTML לתוך ה-div שבו מוצגים הלקוחות
        const clientListDiv = document.getElementById("client-list");
        clientListDiv.innerHTML = data;

        // חיפוש והרצת סקריפטים חדשים שמתווספים ל-HTML
        const scripts = clientListDiv.getElementsByTagName("script");
        for (let script of scripts) {
            eval(script.innerHTML);
        }
    };


    return (
        <div>
            <h1>System Management</h1>
            <input
                type="text"
                placeholder="Client Name"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
            />
            <input
                type="email"
                placeholder="Client Email"
                value={clientEmail}
                onChange={(e) => setClientEmail(e.target.value)}
            />
            <button onClick={addClient}>Add Client</button>
            <button onClick={showClients}>Show Clients</button>
            <div id="client-list"></div>
        </div>
    );
}

export default System;
